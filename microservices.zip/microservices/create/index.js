const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

const Post = require('./Post');
app.use(cors());

app.use(express.json());

app.post('/', async (req, res, next) => {
  try {
    const post = await Post.create({
	title:req.body.title,
	desc:req.body.desc
    });
    return res.json({
      post,
    });
  } catch (error) {
    return res.json({
      message: 'Internal server error',
      error: error.message,
    });
  }
});

mongoose
  .connect(
    'mongodb+srv://elicon:1234@cluster0ritu.adt1u.mongodb.net/?retryWrites=true&w=majority'
  )
  .then(() => {
    console.log('db connected');
    return app.listen(3000);
  })
  .then(() => {
    console.log('app started/ post create service');
  })
  .catch((e) => {
    console.log(e.message);
  });

