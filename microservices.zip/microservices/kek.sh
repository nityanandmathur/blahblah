docker run -d -p 3000:3000 --name get-service node-microservice/get
docker run -d -p 3001:3000 --name create-service node-microservice/create 
docker run -d -p 3002:3000 --name delete-service node-microservice/delete
